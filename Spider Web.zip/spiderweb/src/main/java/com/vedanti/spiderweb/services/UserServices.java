package com.vedanti.spiderweb.services;

import org.springframework.stereotype.Service;

import com.vedanti.spiderweb.entities.User;
import java.sql.*;

@Service
public class UserServices {
	
	public String checkUser(String id,String ps)
	{
		String status="";
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			pst=con.prepareStatement("select *from users where userid=? and pswd=?");
			pst.setString(1,id);
			pst.setString(2,ps);
			rs=pst.executeQuery();
			if(rs.next())
				status="LoginSuccess.jsp";
			else
				status="Error.jsp";
			
			
			
		}
		catch(Exception e)
		{
		  System.out.println(e);	
		}
		
		return status;
	}
	


	public String addNewUser(User u)
	{
		String stat="";
		Connection con;
		PreparedStatement pst;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			pst=con.prepareStatement("insert into users values(?,?,?,?,?,?,?)");
			pst.setString(1, u.getUserid());
			pst.setString(2, u.getPswd());
			pst.setString(3, u.getUsernm());
			pst.setString(4, u.getUsertype());
			pst.setString(5, u.getUserstatus());
			pst.setInt(6, u.getAccno());
			pst.setString(7, u.getMobile());
			pst.executeUpdate();
			con.close();
			stat="success";
		}
		catch(Exception e)
		{
			stat="error";
			System.out.println(e);
		}
		
		return stat;
	}

}

