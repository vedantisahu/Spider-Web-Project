package com.vedanti.spiderweb.services;

import com.vedanti.spiderweb.entities.Car;
import java.sql.*;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class CarServices {
	
	public String addNewCar(Car c)
	{
		String stat="";
		Connection con;
		PreparedStatement pst;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			pst=con.prepareStatement("insert into products values(?,?,?,?)");
			pst.setString(1,c.getProdid());
			pst.setString(2,c.getProdnm());
			pst.setString(3,c.getCompany());
			pst.setFloat(4,c.getPrice());
			pst.executeUpdate();
			stat="CarEntrySuccess.jsp";
		}
		catch(Exception e)
		{
			System.out.println(e);
			stat="CarEntryFailed.jsp";
		}
		
		return stat;
	}
	
	public ArrayList<Car> generateCarReport()
	{
		ArrayList<Car> list = new ArrayList<>();
		Car obj;
		Connection con;
		Statement st;
		ResultSet rs;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://bswesglqs7ttj4hubtrd-mysql.services.clever-cloud.com:3306/bswesglqs7ttj4hubtrd?user=uq6i9injtx4g93ec&password=eh866JcmjGVA0l6gwd8A");
			st=con.createStatement();
			rs=st.executeQuery("select *from products");
			
			while(rs.next()) 
			{
				obj=new Car();
				obj.setProdid(rs.getString("prodid"));
				obj.setProdnm(rs.getString("prodnm"));
				obj.setCompany(rs.getString("company"));
				obj.setPrice(rs.getFloat("price"));
				list.add(obj);
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return list;
	}
	
	 

}
