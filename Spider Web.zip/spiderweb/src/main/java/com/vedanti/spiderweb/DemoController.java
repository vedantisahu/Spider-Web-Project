package com.vedanti.spiderweb;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vedanti.spiderweb.services.CarServices;
import com.vedanti.spiderweb.services.UserServices;
import com.vedanti.spiderweb.entities.Car;
import com.vedanti.spiderweb.entities.User;

@Controller
public class DemoController
{
	@Autowired
	UserServices us;
	
	@Autowired
	CarServices cs;
	
	
    @GetMapping("/")
	public String home() 
    {
    	return "index.jsp";
    }
    
    @PostMapping("/login")
    public String login(String userid,String pass)
    {
      	String stat="";
      	//UserServices us=new UserServices();
      	stat= us.checkUser(userid,pass);
      	return stat;
    }
    
    @GetMapping("/newuser")
    public String newUser()
    {
    	return "NewUser.jsp";
    }
    
    @PostMapping("/register")
    public String registerUser(User u)
    {
    	String status=us.addNewUser(u);
    	if(status.equals("success"))
    		return"UserRegistrationSuccess.jsp";
    	else
    	return "Error.jsp";
    }
    
    @GetMapping("/newcar")
    public String newCar()
    {
    	return "NewCarEntry.jsp";
    }
    @PostMapping("/addcar")
    public String addCar(Car c)
    {
    	String stat=cs.addNewCar(c);
    	
    	return stat;
    }

    @GetMapping("/carreport")
    public ModelAndView showCarReport()
    {
    	ModelAndView mv=new ModelAndView();
    	ArrayList<Car> carlist=cs.generateCarReport();
    	mv.setViewName("CarReport.jsp");
    	mv.addObject("carmodellist",carlist);
    	return mv;
    }
    

}
