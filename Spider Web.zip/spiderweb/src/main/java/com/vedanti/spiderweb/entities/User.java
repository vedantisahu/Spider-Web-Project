package com.vedanti.spiderweb.entities;

public class User 
{
  private String userid;
  private String pswd;
  private String usernm;
  private String usertype;
  private String userstatus;
  private int accno;
  private String mobile;
public String getUserid() {
	return userid;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public String getPswd() {
	return pswd;
}
public void setPswd(String pswd) {
	this.pswd = pswd;
}
public String getUsernm() {
	return usernm;
}
public void setUsernm(String usernm) {
	this.usernm = usernm;
}
public String getUsertype() {
	return usertype;
}
public void setUsertype(String usertype) {
	this.usertype = usertype;
}
public String getUserstatus() {
	return userstatus;
}
public void setUserstatus(String userstatus) {
	this.userstatus = userstatus;
}
public int getAccno() {
	return accno;
}
public void setAccno(int accno) {
	this.accno = accno;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
  
  
}
