package com.vedanti.spiderweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpiderwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
